package Cupcake;

public class Bottom {

    int bno;
    String bottom;
    float price;

    public Bottom(int bno, String bottom, float price) {
        this.bno = bno;
        this.bottom = bottom;
        this.price = price;
    }

    public int getBno() {
        return bno;
    }

    public String getBottom() {
        return bottom;
    }

    public float getPrice() {
        return price;
    }
}
